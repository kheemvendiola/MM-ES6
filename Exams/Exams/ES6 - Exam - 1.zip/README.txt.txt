Exercise Objectives:
1) carefully identify and convert at least 20 "var" declarations to "let"
2) carefully identify and convert at least 13 "var" declarations to "const"
3) carefully identify and convert at least 4  classic "function" declarations to "arrow functions"
4) fix runtime errors (hint: all related to the previous lesson"

you have 40minutes to do all tasks.